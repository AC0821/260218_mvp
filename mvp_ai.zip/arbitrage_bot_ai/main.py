#!/usr/bin/env python3
"""
Cryptocurrency Arbitrage Trading Bot

A sophisticated automated trading system that detects and executes arbitrage
opportunities across cryptocurrency exchanges using triangular and exchange
arbitrage strategies.

This module serves as the main entry point for the arbitrage trading bot,
providing command-line interface and orchestration of trading engines.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Dict, Any, Optional

# Configure logging with comprehensive settings
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('arbitrage.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)


class ConfigurationError(Exception):
    """Raised when configuration loading or validation fails."""
    pass


class EngineInitializationError(Exception):
    """Raised when trading engine initialization fails."""
    pass


def load_config(config_file: str = 'arbitrage_config.json') -> Dict[str, Any]:
    """
    Load and validate configuration from JSON file.
    
    This function reads the configuration file containing exchange settings,
    trading pairs, and API key file paths. It performs basic validation
    to ensure the file exists and contains valid JSON.
    
    Args:
        config_file: Path to the configuration JSON file. Defaults to
                     'arbitrage_config.json' in the current directory.
    
    Returns:
        A dictionary containing the parsed configuration data with the
        following structure:
        {
            'triangular': {...},  # Optional triangular arbitrage config
            'exchange': {...}     # Optional exchange arbitrage config
        }
    
    Raises:
        ConfigurationError: If the configuration file cannot be found,
                           parsed, or is invalid.
        FileNotFoundError: If the configuration file does not exist.
        json.JSONDecodeError: If the file contains invalid JSON.
    
    Example:
        >>> config = load_config('arbitrage_config.json')
        >>> print(config['triangular']['exchange'])
        'bittrex'
    """
    config_path = Path(config_file)
    
    if not config_path.exists():
        error_msg = (
            f"Configuration file '{config_file}' not found. "
            f"Please ensure the file exists in the current directory."
        )
        logger.error(error_msg)
        raise ConfigurationError(error_msg)
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config: Dict[str, Any] = json.load(f)
        
        logger.info(f"Configuration loaded successfully from '{config_file}'")
        return config
        
    except json.JSONDecodeError as e:
        error_msg = (
            f"Invalid JSON syntax in configuration file '{config_file}': {e}. "
            f"Please check the file for syntax errors."
        )
        logger.error(error_msg)
        raise ConfigurationError(error_msg) from e
        
    except Exception as e:
        error_msg = f"Unexpected error loading configuration: {e}"
        logger.error(error_msg, exc_info=True)
        raise ConfigurationError(error_msg) from e


def validate_config_section(
    config: Dict[str, Any],
    section_name: str,
    required_keys: Optional[list[str]] = None
) -> bool:
    """
    Validate that a configuration section exists and contains required keys.
    
    Args:
        config: The configuration dictionary to validate.
        section_name: Name of the configuration section to check.
        required_keys: Optional list of keys that must exist in the section.
    
    Returns:
        True if the section exists and contains all required keys.
    
    Raises:
        ConfigurationError: If the section is missing or incomplete.
    """
    if section_name not in config:
        error_msg = (
            f"Configuration section '{section_name}' not found. "
            f"Please ensure your configuration file contains this section."
        )
        logger.error(error_msg)
        raise ConfigurationError(error_msg)
    
    if required_keys:
        section = config[section_name]
        missing_keys = [key for key in required_keys if key not in section]
        if missing_keys:
            error_msg = (
                f"Configuration section '{section_name}' is missing required keys: "
                f"{', '.join(missing_keys)}"
            )
            logger.error(error_msg)
            raise ConfigurationError(error_msg)
    
    return True


def initialize_triangular_engine(
    config: Dict[str, Any],
    mock_mode: bool
) -> Any:
    """
    Initialize the triangular arbitrage trading engine.
    
    Args:
        config: Configuration dictionary containing 'triangular' section.
        mock_mode: If True, run in mock mode (no real trades executed).
    
    Returns:
        An initialized CryptoEngineTriArbitrage instance.
    
    Raises:
        ConfigurationError: If triangular configuration is missing or invalid.
        EngineInitializationError: If engine initialization fails.
    """
    validate_config_section(config, 'triangular')
    
    try:
        from engines.triangular_arbitrage import CryptoEngineTriArbitrage
        
        engine = CryptoEngineTriArbitrage(
            config['triangular'],
            mock=mock_mode
        )
        
        logger.info("Triangular Arbitrage Engine initialized successfully")
        return engine
        
    except ImportError as e:
        error_msg = f"Failed to import triangular arbitrage engine: {e}"
        logger.error(error_msg)
        raise EngineInitializationError(error_msg) from e
        
    except Exception as e:
        error_msg = f"Failed to initialize triangular arbitrage engine: {e}"
        logger.error(error_msg, exc_info=True)
        raise EngineInitializationError(error_msg) from e


def initialize_exchange_engine(
    config: Dict[str, Any],
    mock_mode: bool
) -> Any:
    """
    Initialize the exchange arbitrage trading engine.
    
    Args:
        config: Configuration dictionary containing 'exchange' section.
        mock_mode: If True, run in mock mode (no real trades executed).
    
    Returns:
        An initialized CryptoEngineExArbitrage instance.
    
    Raises:
        ConfigurationError: If exchange configuration is missing or invalid.
        EngineInitializationError: If engine initialization fails.
    """
    validate_config_section(config, 'exchange')
    
    try:
        from engines.exchange_arbitrage import CryptoEngineExArbitrage
        
        engine = CryptoEngineExArbitrage(
            config['exchange'],
            mock=mock_mode
        )
        
        logger.info("Exchange Arbitrage Engine initialized successfully")
        return engine
        
    except ImportError as e:
        error_msg = f"Failed to import exchange arbitrage engine: {e}"
        logger.error(error_msg)
        raise EngineInitializationError(error_msg) from e
        
    except Exception as e:
        error_msg = f"Failed to initialize exchange arbitrage engine: {e}"
        logger.error(error_msg, exc_info=True)
        raise EngineInitializationError(error_msg) from e


def create_argument_parser() -> argparse.ArgumentParser:
    """
    Create and configure the command-line argument parser.
    
    Returns:
        A configured ArgumentParser instance with all required arguments.
    """
    parser = argparse.ArgumentParser(
        description=(
            'Cryptocurrency Arbitrage Trading Bot - '
            'Automated detection and execution of arbitrage opportunities'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run triangular arbitrage in mock mode (safe, no real trades)
  python main.py -m triangular
  
  # Run exchange arbitrage in production mode (real trades)
  python main.py -m exchange -p
  
  # Use custom configuration file
  python main.py -m triangular -c my_config.json

For more information, see the README.md file.
        """
    )
    
    parser.add_argument(
        '-m', '--mode',
        choices=['triangular', 'exchange'],
        required=True,
        help='Arbitrage mode: "triangular" for single-exchange arbitrage, '
             '"exchange" for cross-exchange arbitrage'
    )
    
    parser.add_argument(
        '-p', '--production',
        action='store_true',
        help='Enable production mode (disables mock mode). '
             'WARNING: This will execute real trades with real funds!'
    )
    
    parser.add_argument(
        '-c', '--config',
        type=str,
        default='arbitrage_config.json',
        help='Path to configuration file (default: arbitrage_config.json)'
    )
    
    return parser


def main() -> int:
    """
    Main entry point for the arbitrage trading bot.
    
    This function orchestrates the entire bot lifecycle:
    1. Parse command-line arguments
    2. Load and validate configuration
    3. Initialize the appropriate trading engine
    4. Start the engine and handle runtime events
    
    Returns:
        Exit code: 0 for success, non-zero for errors.
    
    Raises:
        ConfigurationError: If configuration is invalid.
        EngineInitializationError: If engine initialization fails.
        KeyboardInterrupt: If user interrupts execution (handled gracefully).
    """
    parser = create_argument_parser()
    args = parser.parse_args()
    
    try:
        # Load configuration
        logger.info("Loading configuration...")
        config = load_config(args.config)
        
        # Determine execution mode
        is_mock_mode = not args.production
        
        if is_mock_mode:
            logger.warning("=" * 70)
            logger.warning("RUNNING IN MOCK MODE - NO REAL ORDERS WILL BE PLACED")
            logger.warning("This is safe mode for testing. Use -p flag for production.")
            logger.warning("=" * 70)
        else:
            logger.warning("=" * 70)
            logger.warning("PRODUCTION MODE ENABLED - REAL TRADES WILL BE EXECUTED")
            logger.warning("Ensure you have tested thoroughly in mock mode first!")
            logger.warning("=" * 70)
        
        # Initialize appropriate engine
        logger.info(f"Initializing {args.mode} arbitrage engine...")
        
        if args.mode == 'triangular':
            engine = initialize_triangular_engine(config, is_mock_mode)
        elif args.mode == 'exchange':
            engine = initialize_exchange_engine(config, is_mock_mode)
        else:
            # This should never happen due to choices constraint, but handle it anyway
            error_msg = f"Unsupported mode: {args.mode}"
            logger.error(error_msg)
            return 1
        
        # Start the engine
        logger.info(f"Starting {args.mode} arbitrage engine...")
        logger.info("The bot will continuously monitor for arbitrage opportunities.")
        logger.info("Press Ctrl+C to stop the bot gracefully.")
        logger.info("-" * 70)
        
        engine.run()
        
        return 0
        
    except KeyboardInterrupt:
        logger.info("")
        logger.info("Shutdown signal received. Stopping bot gracefully...")
        logger.info("Thank you for using the Cryptocurrency Arbitrage Trading Bot!")
        return 0
        
    except (ConfigurationError, EngineInitializationError) as e:
        logger.error(f"Initialization failed: {e}")
        return 1
        
    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        logger.error("Please check the logs for more details.")
        return 1


if __name__ == '__main__':
    """
    Entry point when script is executed directly.
    
    This allows the module to be run as a standalone script:
    $ python main.py -m triangular
    
    Or imported as a module:
    >>> from main import load_config
    """
    exit_code = main()
    sys.exit(exit_code)
