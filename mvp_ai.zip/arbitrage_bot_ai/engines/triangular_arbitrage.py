"""
Triangular Arbitrage Trading Engine

This module implements a sophisticated triangular arbitrage detection and execution
system for cryptocurrency exchanges. Triangular arbitrage exploits price
inefficiencies across three currency pairs on a single exchange.

The engine continuously monitors order books, calculates potential profit
opportunities, and executes trades when profitable conditions are detected.
"""

from __future__ import annotations

import time
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass

import grequests

from engines.exchanges.loader import EngineLoader

logger = logging.getLogger(__name__)


@dataclass
class OrderInfo:
    """Represents a single order to be placed on an exchange."""
    ticker_pair: str
    action: str  # 'bid' or 'ask'
    price: float
    amount: float


@dataclass
class ArbitrageOpportunity:
    """Represents a detected arbitrage opportunity."""
    status: int  # 0 = no opportunity, 1 = bid route, 2 = ask route
    order_info: Optional[List[Dict[str, Any]]] = None
    profit: Optional[float] = None
    fee: Optional[float] = None


class CryptoEngineTriArbitrage:
    """
    Triangular Arbitrage Trading Engine.
    
    This engine detects and executes triangular arbitrage opportunities by
    monitoring three currency pairs on a single exchange and identifying
    profitable circular trading paths.
    
    Attributes:
        exchange: Configuration dictionary containing exchange settings.
        mock: If True, operates in mock mode without placing real orders.
        minProfitUSDT: Minimum profit threshold in USDT to execute trades.
        hasOpenOrder: Flag indicating if there are pending orders.
        openOrderCheckCount: Counter for open order checks.
        maxOpenOrderChecks: Maximum number of checks before cancelling orders.
        engine: Exchange engine instance for API interactions.
    
    Example:
        >>> config = {
        ...     'exchange': 'bittrex',
        ...     'keyFile': 'keys/bittrex.key',
        ...     'tickerPairA': 'BTC-ETH',
        ...     'tickerPairB': 'ETH-LTC',
        ...     'tickerPairC': 'BTC-LTC',
        ...     'tickerA': 'BTC',
        ...     'tickerB': 'ETH',
        ...     'tickerC': 'LTC'
        ... }
        >>> engine = CryptoEngineTriArbitrage(config, mock=True)
        >>> engine.run()
    """
    
    def __init__(
        self,
        exchange_config: Dict[str, Any],
        mock: bool = False
    ) -> None:
        """
        Initialize the triangular arbitrage engine.
        
        Args:
            exchange_config: Dictionary containing exchange configuration with
                           keys: 'exchange', 'keyFile', 'tickerPairA/B/C',
                           'tickerA/B/C'.
            mock: If True, run in mock mode (no real orders placed).
        
        Raises:
            Exception: If exchange engine initialization fails.
        """
        self.exchange: Dict[str, Any] = exchange_config
        self.mock: bool = mock
        self.minProfitUSDT: float = 0.3
        self.hasOpenOrder: bool = True
        self.openOrderCheckCount: int = 0
        self.maxOpenOrderChecks: int = 5
        
        try:
            self.engine = EngineLoader.getEngine(
                self.exchange['exchange'],
                self.exchange['keyFile']
            )
            logger.info(
                f"Exchange engine initialized: {self.exchange['exchange']}"
            )
        except Exception as e:
            logger.error(f"Failed to initialize exchange engine: {e}")
            raise

    def start_engine(self) -> None:
        """
        Start the main trading loop.
        
        This method runs continuously, checking for arbitrage opportunities
        and managing order execution. The loop handles:
        - Open order management
        - Balance verification
        - Order book monitoring
        - Trade execution
        
        The loop continues until interrupted (Ctrl+C) or an unrecoverable
        error occurs.
        
        Raises:
            KeyboardInterrupt: When user interrupts execution (handled gracefully).
        """
        logger.info("Starting Triangular Arbitrage Engine...")
        
        if self.mock:
            logger.warning("=" * 70)
            logger.warning("MOCK MODE ENABLED - NO ORDERS WILL BE PLACED")
            logger.warning("=" * 70)
        
        while True:
            try:
                if not self.mock and self.hasOpenOrder:
                    self.check_open_order()
                elif self.check_balance():
                    opportunity = self.check_order_book()
                    if opportunity.status > 0 and opportunity.order_info:
                        self.place_order(opportunity.order_info)
            except KeyboardInterrupt:
                logger.info("Shutdown signal received. Stopping engine...")
                raise
            except Exception as e:
                logger.error(f"Error in main loop: {e}", exc_info=True)
            
            time.sleep(self.engine.sleepTime)
    
    def check_open_order(self) -> bool:
        """
        Check for open orders and manage their lifecycle.
        
        This method queries the exchange for pending orders and handles
        them appropriately. If orders remain open after maximum checks,
        they are cancelled to free up trading capacity.
        
        Returns:
            True if check completed successfully, False otherwise.
        """
        if self.openOrderCheckCount >= self.maxOpenOrderChecks:
            logger.warning(
                "Maximum open order checks reached. Cancelling all orders."
            )
            self.cancel_all_orders()
            return True
        
        logger.debug("Checking for open orders...")
        
        try:
            request_list = [self.engine.get_open_order()]
            responses = self.send_request(request_list)
            
            if not responses or not responses[0]:
                logger.error("Failed to retrieve open orders")
                return False
            
            if responses[0].parsed:
                self.engine.openOrders = responses[0].parsed
                logger.info(
                    f"Found {len(self.engine.openOrders)} open order(s)"
                )
                self.openOrderCheckCount += 1
            else:
                self.hasOpenOrder = False
                logger.info("No open orders. Ready to check opportunities.")
            
            return True
            
        except Exception as e:
            logger.error(f"Error checking open orders: {e}")
            return False
    
    def cancel_all_orders(self) -> None:
        """
        Cancel all pending orders on the exchange.
        
        This method sends cancellation requests for all open orders,
        clearing the order queue to allow new trading opportunities.
        """
        logger.info("Cancelling all open orders...")
        
        if not hasattr(self.engine, 'openOrders') or not self.engine.openOrders:
            logger.info("No open orders to cancel")
            self.hasOpenOrder = False
            return
        
        cancel_requests = []
        for order in self.engine.openOrders:
            logger.debug(f"Cancelling order: {order.get('orderId', 'unknown')}")
            cancel_requests.append(
                self.engine.cancel_order(order['orderId'])
            )
        
        try:
            responses = self.send_request(cancel_requests)
            logger.info(f"Successfully cancelled {len(responses)} order(s)")
        except Exception as e:
            logger.error(f"Error cancelling orders: {e}")
        
        self.engine.openOrders = []
        self.hasOpenOrder = False

    def check_balance(self) -> bool:
        """
        Verify account balances for required currencies.
        
        This method checks that sufficient balances exist for all three
        currencies required for triangular arbitrage trading.
        
        Returns:
            True if balance check succeeded, False otherwise.
        """
        try:
            tickers = [
                self.exchange['tickerA'],
                self.exchange['tickerB'],
                self.exchange['tickerC']
            ]
            
            request_list = [self.engine.get_balance(tickers)]
            responses = self.send_request(request_list)
            
            self.engine.balance = responses[0].parsed
            
            logger.debug("Current balances:")
            for ticker in tickers:
                balance = self.engine.balance.get(ticker, 0)
                logger.debug(f"  {ticker}: {balance}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error checking balance: {e}")
            return False
    
    def check_order_book(self) -> ArbitrageOpportunity:
        """
        Analyze order books to detect arbitrage opportunities.
        
        This method performs comprehensive analysis of order books for
        three trading pairs, calculating potential profit from both
        bid and ask routes, and determining optimal trade amounts.
        
        Returns:
            ArbitrageOpportunity object containing opportunity details
            or status=0 if no opportunity exists.
        """
        # Get last prices for USD conversion
        price_requests = [
            self.engine.get_ticker_lastPrice(self.exchange['tickerA']),
            self.engine.get_ticker_lastPrice(self.exchange['tickerB']),
            self.engine.get_ticker_lastPrice(self.exchange['tickerC']),
        ]
        
        last_prices: List[float] = []
        for response in self.send_request(price_requests):
            price_value = next(iter(response.parsed.values()))
            last_prices.append(price_value)
        
        # Get order book data for all pairs
        order_book_requests = [
            self.engine.get_ticker_orderBook_innermost(
                self.exchange['tickerPairA']
            ),
            self.engine.get_ticker_orderBook_innermost(
                self.exchange['tickerPairB']
            ),
            self.engine.get_ticker_orderBook_innermost(
                self.exchange['tickerPairC']
            ),
        ]
        
        responses = self.send_request(order_book_requests)
        
        if self.mock:
            logger.debug(
                f"Order books - {self.exchange['tickerPairA']}: "
                f"{responses[0].parsed}, {self.exchange['tickerPairB']}: "
                f"{responses[1].parsed}, {self.exchange['tickerPairC']}: "
                f"{responses[2].parsed}"
            )
        
        # Calculate arbitrage opportunities for both routes
        bid_route_result = self._calculate_bid_route(responses)
        ask_route_result = self._calculate_ask_route(responses)
        
        # Determine optimal route
        status, route_result = self._select_optimal_route(
            bid_route_result,
            ask_route_result,
            last_prices
        )
        
        if status == 0:
            return ArbitrageOpportunity(status=0)
        
        # Calculate maximum tradeable amounts
        max_amounts = self.get_max_amount(
            last_prices,
            responses,
            status
        )
        
        # Calculate fees and profit
        fee = self._calculate_total_fee(max_amounts, last_prices)
        profit = self._calculate_profit(
            route_result,
            status,
            last_prices,
            max_amounts
        )
        
        # Verify profit exceeds minimum threshold
        net_profit = profit - fee
        if net_profit <= self.minProfitUSDT:
            return ArbitrageOpportunity(status=0)
        
        # Generate order information
        order_info = self._generate_order_info(
            responses,
            max_amounts,
            status
        )
        
        logger.info(
            f"Arbitrage opportunity detected - Route {status}: "
            f"Result={route_result:.6f}, Profit=${profit:.2f}, "
            f"Fee=${fee:.2f}, Net Profit=${net_profit:.2f}"
        )
        
        return ArbitrageOpportunity(
            status=status,
            order_info=order_info,
            profit=profit,
            fee=fee
        )
    
    def _calculate_bid_route(
        self,
        responses: List[Any]
    ) -> float:
        """
        Calculate profit ratio for bid route (BTC -> ETH -> LTC -> BTC).
        
        Args:
            responses: List of order book responses for the three pairs.
        
        Returns:
            Profit ratio (values > 1.0 indicate profit).
        """
        return (
            1.0 / responses[0].parsed['ask']['price']
            / responses[1].parsed['ask']['price']
            * responses[2].parsed['bid']['price']
        )
    
    def _calculate_ask_route(
        self,
        responses: List[Any]
    ) -> float:
        """
        Calculate profit ratio for ask route (ETH -> BTC -> LTC -> ETH).
        
        Args:
            responses: List of order book responses for the three pairs.
        
        Returns:
            Profit ratio (values > 1.0 indicate profit).
        """
        return (
            1.0 * responses[0].parsed['bid']['price']
            / responses[2].parsed['ask']['price']
            * responses[1].parsed['bid']['price']
        )
    
    def _select_optimal_route(
        self,
        bid_result: float,
        ask_result: float,
        last_prices: List[float]
    ) -> Tuple[int, float]:
        """
        Select the most profitable route between bid and ask routes.
        
        Args:
            bid_result: Profit ratio for bid route.
            ask_result: Profit ratio for ask route.
            last_prices: Last traded prices for USD conversion.
        
        Returns:
            Tuple of (status, result) where status is 0/1/2 and result
            is the profit ratio.
        """
        if bid_result > 1.0:
            if ask_result > 1.0:
                # Both profitable - choose better one
                bid_profit_value = (bid_result - 1.0) * last_prices[0]
                ask_profit_value = (ask_result - 1.0) * last_prices[1]
                if bid_profit_value > ask_profit_value:
                    return (1, bid_result)
                else:
                    return (2, ask_result)
            return (1, bid_result)
        elif ask_result > 1.0:
            return (2, ask_result)
        return (0, 0.0)
    
    def _calculate_total_fee(
        self,
        amounts: List[float],
        prices: List[float]
    ) -> float:
        """
        Calculate total trading fees for all three trades.
        
        Args:
            amounts: Trade amounts for each currency.
            prices: Last prices for each currency.
        
        Returns:
            Total fee amount in USD.
        """
        total_value = sum(amount * price for amount, price in zip(amounts, prices))
        return total_value * self.engine.feeRatio
    
    def _calculate_profit(
        self,
        route_result: float,
        status: int,
        prices: List[float],
        amounts: List[float]
    ) -> float:
        """
        Calculate gross profit for the selected route.
        
        Args:
            route_result: Profit ratio for the route.
            status: Route status (1 or 2).
            prices: Last prices for each currency.
            amounts: Trade amounts for each currency.
        
        Returns:
            Gross profit amount in USD.
        """
        if status == 1:
            return (route_result - 1.0) * prices[0] * amounts[0]
        else:
            return (route_result - 1.0) * prices[1] * amounts[1]
    
    def _generate_order_info(
        self,
        responses: List[Any],
        max_amounts: List[float],
        status: int
    ) -> List[Dict[str, Any]]:
        """
        Generate order information dictionaries for execution.
        
        Args:
            responses: Order book responses.
            max_amounts: Maximum tradeable amounts.
            status: Route status (1 or 2).
        
        Returns:
            List of order dictionaries ready for execution.
        """
        if status == 1:
            return [
                {
                    "tickerPair": self.exchange['tickerPairA'],
                    "action": "bid",
                    "price": responses[0].parsed['ask']['price'],
                    "amount": max_amounts[0]
                },
                {
                    "tickerPair": self.exchange['tickerPairB'],
                    "action": "bid",
                    "price": responses[1].parsed['ask']['price'],
                    "amount": max_amounts[1]
                },
                {
                    "tickerPair": self.exchange['tickerPairC'],
                    "action": "ask",
                    "price": responses[2].parsed['bid']['price'],
                    "amount": max_amounts[2]
                }
            ]
        else:
            return [
                {
                    "tickerPair": self.exchange['tickerPairA'],
                    "action": "ask",
                    "price": responses[0].parsed['bid']['price'],
                    "amount": max_amounts[0]
                },
                {
                    "tickerPair": self.exchange['tickerPairB'],
                    "action": "ask",
                    "price": responses[1].parsed['bid']['price'],
                    "amount": max_amounts[1]
                },
                {
                    "tickerPair": self.exchange['tickerPairC'],
                    "action": "bid",
                    "price": responses[2].parsed['ask']['price'],
                    "amount": max_amounts[2]
                }
            ]

    def get_max_amount(
        self,
        last_prices: List[float],
        order_book_res: List[Any],
        status: int
    ) -> List[float]:
        """
        Calculate maximum tradeable amount for each currency.
        
        This method determines the maximum amount that can be traded by
        considering balance constraints, order book depth, and fee
        implications for each currency in the triangle.
        
        Args:
            last_prices: Last traded prices for USD conversion.
            order_book_res: Order book responses for all three pairs.
            status: Route status (1 for bid route, 2 for ask route).
        
        Returns:
            List of maximum tradeable amounts for each currency.
        """
        max_usdt: Optional[float] = None
        ticker_indices = ['tickerA', 'tickerB', 'tickerC']
        
        for index, ticker_index in enumerate(ticker_indices):
            # Determine bid/ask direction based on route
            if index < 2:
                bid_ask = -1  # Buying first two currencies
            else:
                bid_ask = 1   # Selling third currency
            
            if status == 2:
                bid_ask *= -1  # Reverse for ask route
            
            bid_ask_str = 'bid' if bid_ask == 1 else 'ask'
            ticker = self.exchange[ticker_index]
            
            order_book_amount = order_book_res[index].parsed[bid_ask_str]['amount']
            own_balance = self.engine.balance.get(ticker, 0)
            max_balance = min(order_book_amount, own_balance)
            
            logger.debug(
                f"{ticker} - Order book: {order_book_amount:.8f}, "
                f"Balance: {own_balance:.8f}, Max: {max_balance:.8f}"
            )
            
            usdt_value = max_balance * last_prices[index] * (1 - self.engine.feeRatio)
            
            if max_usdt is None or usdt_value < max_usdt:
                max_usdt = usdt_value
        
        # Convert USD value back to currency amounts
        return [max_usdt / price for price in last_prices]

    def place_order(self, order_info: List[Dict[str, Any]]) -> None:
        """
        Execute orders on the exchange.
        
        This method places the three orders required for triangular
        arbitrage execution. In mock mode, orders are simulated without
        actual execution.
        
        Args:
            order_info: List of order dictionaries containing tickerPair,
                       action, price, and amount.
        
        Raises:
            Exception: If order placement fails in production mode.
        """
        logger.info(f"Preparing to place {len(order_info)} orders:")
        
        for order in order_info:
            logger.info(
                f"  {order['action'].upper()} {order['amount']:.8f} "
                f"{order['tickerPair']} @ {order['price']:.8f}"
            )
        
        order_requests = [
            self.engine.place_order(
                order['tickerPair'],
                order['action'],
                order['amount'],
                order['price']
            )
            for order in order_info
        ]
        
        if not self.mock:
            try:
                responses = self.send_request(order_requests)
                logger.info("Orders placed successfully")
            except Exception as e:
                logger.error(f"Error placing orders: {e}")
                raise
        else:
            logger.info("Mock mode: Orders not actually placed")
        
        self.hasOpenOrder = True
        self.openOrderCheckCount = 0

    def send_request(self, requests_list: List[Any]) -> List[Any]:
        """
        Send multiple API requests asynchronously.
        
        Args:
            requests_list: List of grequests request objects.
        
        Returns:
            List of response objects.
        
        Raises:
            Exception: If any request fails.
        """
        responses = grequests.map(requests_list)
        
        for i, response in enumerate(responses):
            if not response:
                error_msg = f"Request {i} failed"
                logger.error(f"{error_msg}: {responses}")
                raise Exception(error_msg)
        
        return responses

    def run(self) -> None:
        """Start the trading engine."""
        self.start_engine()


if __name__ == '__main__':
    # Example usage for testing
    exchange_config = {
        'exchange': 'bittrex',
        'keyFile': '../keys/bittrex.key',
        'tickerPairA': 'BTC-ETH',
        'tickerPairB': 'ETH-LTC',
        'tickerPairC': 'BTC-LTC',
        'tickerA': 'BTC',
        'tickerB': 'ETH',
        'tickerC': 'LTC'
    }
    
    engine = CryptoEngineTriArbitrage(exchange_config, mock=True)
    engine.run()
