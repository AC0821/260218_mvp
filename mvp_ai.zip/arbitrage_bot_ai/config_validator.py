#!/usr/bin/env python3
"""
Configuration Validator
Validates arbitrage configuration files
"""

import json
import sys
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def validate_triangular_config(config):
    """Validate triangular arbitrage configuration."""
    required_keys = [
        'exchange', 'keyFile', 'tickerPairA', 'tickerPairB', 'tickerPairC',
        'tickerA', 'tickerB', 'tickerC'
    ]
    
    missing_keys = [key for key in required_keys if key not in config]
    if missing_keys:
        logger.error(f"Missing required keys in triangular config: {missing_keys}")
        return False
    
    # Check if key file exists
    key_file = Path(config['keyFile'])
    if not key_file.exists():
        logger.warning(f"Key file not found: {key_file}")
        logger.info("Make sure to create the key file from the sample")
    
    return True


def validate_exchange_config(config):
    """Validate exchange arbitrage configuration."""
    required_exchange_keys = ['exchange', 'keyFile', 'tickerPair', 'tickerA', 'tickerB']
    
    if 'exchangeA' not in config:
        logger.error("Missing 'exchangeA' in exchange config")
        return False
    
    if 'exchangeB' not in config:
        logger.error("Missing 'exchangeB' in exchange config")
        return False
    
    for exchange_name in ['exchangeA', 'exchangeB']:
        exchange_config = config[exchange_name]
        missing_keys = [
            key for key in required_exchange_keys
            if key not in exchange_config
        ]
        if missing_keys:
            logger.error(
                f"Missing required keys in {exchange_name}: {missing_keys}"
            )
            return False
        
        # Check if key file exists
        key_file = Path(exchange_config['keyFile'])
        if not key_file.exists():
            logger.warning(f"Key file not found for {exchange_name}: {key_file}")
            logger.info("Make sure to create the key file from the sample")
    
    return True


def validate_config_file(config_path='arbitrage_config.json'):
    """Validate the entire configuration file."""
    config_file = Path(config_path)
    
    if not config_file.exists():
        logger.error(f"Configuration file not found: {config_path}")
        return False
    
    try:
        with open(config_file, 'r') as f:
            config = json.load(f)
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in configuration file: {e}")
        return False
    
    logger.info(f"Validating configuration file: {config_path}")
    
    # Validate triangular config if present
    if 'triangular' in config:
        logger.info("Validating triangular arbitrage configuration...")
        if not validate_triangular_config(config['triangular']):
            return False
        logger.info("✓ Triangular arbitrage configuration is valid")
    
    # Validate exchange config if present
    if 'exchange' in config:
        logger.info("Validating exchange arbitrage configuration...")
        if not validate_exchange_config(config['exchange']):
            return False
        logger.info("✓ Exchange arbitrage configuration is valid")
    
    if 'triangular' not in config and 'exchange' not in config:
        logger.error("Configuration must contain at least 'triangular' or 'exchange' section")
        return False
    
    logger.info("✓ Configuration file is valid!")
    return True


if __name__ == '__main__':
    config_file = sys.argv[1] if len(sys.argv) > 1 else 'arbitrage_config.json'
    
    if validate_config_file(config_file):
        sys.exit(0)
    else:
        sys.exit(1)
