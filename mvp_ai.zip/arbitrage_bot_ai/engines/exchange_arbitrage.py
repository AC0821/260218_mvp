"""
Exchange Arbitrage Engine - Beginner Friendly Version

What is Exchange Arbitrage?
============================
This is simpler than triangular arbitrage!

Imagine you're watching TWO different exchanges:
- Exchange A: Selling BTC for $50,000
- Exchange B: Buying BTC for $50,100

If you can:
1. Buy BTC on Exchange A for $50,000
2. Sell BTC on Exchange B for $50,100
3. You make $100 profit! (minus trading fees)

The trick is finding these price differences and acting FAST before they disappear!

This bot watches two exchanges and automatically finds these opportunities.
"""

# Import tools we need
import time          # For waiting/delays
import logging       # For writing messages
import grequests    # For making fast API requests to exchanges
from engines.exchanges.loader import EngineLoader  # For loading exchange connections

# Create a logger to write messages
logger = logging.getLogger(__name__)


class CryptoEngineExArbitrage:
    """
    This is the Exchange Arbitrage Engine class.
    
    Think of it like a robot that watches TWO exchanges at the same time.
    Its job is to:
    1. Watch prices on Exchange A and Exchange B
    2. Find when Exchange A's price is different from Exchange B's price
    3. Buy on the cheap exchange, sell on the expensive exchange
    4. Make profit from the difference!
    """
    
    def __init__(self, exchange_params, mock=False):
        """
        This function runs when we create the engine.
        It connects to TWO exchanges and gets ready to trade.
        
        Parameters:
        -----------
        exchange_params: A dictionary with settings for BOTH exchanges:
            - exchangeA: Settings for first exchange
            - exchangeB: Settings for second exchange
        
        mock: If True, the bot runs in "safe mode" - finds opportunities
              but doesn't actually place orders. Good for testing!
        """
        # Save the configuration
        self.exParams = exchange_params
        
        # Are we in mock mode (safe mode)?
        self.mock = mock
        
        # Minimum profit we want (in the base currency)
        # We won't trade unless profit is more than this
        self.minProfit = 0.00005  # Very small amount (adjust based on your currency)
        
        # Track if we have open orders (orders waiting to be filled)
        self.hasOpenOrder = True  # Start by assuming we have open orders
        
        # Count how many times we've checked for open orders
        self.openOrderCheckCount = 0
        
        # Maximum times to check for open orders before cancelling them
        self.maxOpenOrderChecks = 5
        
        # Try to connect to BOTH exchanges
        try:
            # Connect to Exchange A
            self.engineA = EngineLoader.getEngine(
                self.exParams['exchangeA']['exchange'],  # Which exchange (like "bittrex")
                self.exParams['exchangeA']['keyFile']    # Where our API keys are
            )
            
            # Connect to Exchange B
            self.engineB = EngineLoader.getEngine(
                self.exParams['exchangeB']['exchange'],  # Which exchange (like "bitstamp")
                self.exParams['exchangeB']['keyFile']    # Where our API keys are
            )
            
            logger.info(
                f"✓ Connected to {self.exParams['exchangeA']['exchange']} "
                f"and {self.exParams['exchangeB']['exchange']}"
            )
        except Exception as e:
            # If connection failed, show error and stop
            logger.error(f"Failed to connect to exchanges: {e}")
            raise

    def start_engine(self):
        """
        This is the MAIN LOOP - it runs forever until you stop it.
        
        What it does:
        1. Check if we have open orders (orders waiting to be filled)
        2. If no open orders, check our balance on both exchanges
        3. Check the order books on both exchanges
        4. If we find a profitable opportunity, place orders
        5. Wait a bit, then repeat from step 1
        """
        logger.info("Starting Exchange Arbitrage Engine...")
        
        # Show warning if we're in safe mode
        if self.mock:
            logger.warning("=" * 60)
            logger.warning("MOCK MODE ENABLED - NO ORDERS WILL BE PLACED")
            logger.warning("This is SAFE - just testing, no real trades!")
            logger.warning("=" * 60)
        
        # ====================================================================
        # MAIN LOOP - This runs forever (until you press Ctrl+C)
        # ====================================================================
        while True:
            try:
                # Check if we're in production mode AND we have open orders
                if not self.mock and self.hasOpenOrder:
                    # We have orders waiting, check on them
                    self.check_open_order()
                else:
                    # No open orders, check if we have enough balance
                    if self.check_balance():
                        # Check the order books for opportunities
                        book_status = self.check_order_book()
                        
                        # If we found an opportunity (status > 0), place orders!
                        if book_status.get('status'):
                            self.place_order(
                                book_status['status'],
                                book_status['ask'],
                                book_status['bid'],
                                book_status['maxAmount']
                            )
                    else:
                        # Not enough balance, try to rebalance
                        self.rebalance()
                        
            except KeyboardInterrupt:
                # User pressed Ctrl+C to stop
                logger.info("Stopping the bot...")
                raise
            except Exception as e:
                # Something went wrong, but keep running
                logger.error(f"Error in main loop: {e}", exc_info=True)

            # Wait before checking again (don't spam the exchanges!)
            # Wait a bit longer than triangular arbitrage (checking 2 exchanges)
            sleep_time = self.engineA.sleepTime + 10
            time.sleep(sleep_time)
            
    def check_open_order(self):
        """
        Check if we have any open orders on EITHER exchange.
        
        Why do we care?
        - If we have open orders, we can't place new ones
        - We need to wait for them to complete or cancel them
        """
        # If we've checked too many times, just cancel everything
        if self.openOrderCheckCount >= self.maxOpenOrderChecks:
            logger.warning("Checked too many times, cancelling all orders")
            self.cancel_all_orders()
        else:
            # Check what orders are still open on BOTH exchanges
            logger.debug("Checking for open orders on both exchanges...")
            
            # Ask BOTH exchanges: "What orders do I have?"
            request_list = [
                self.engineA.get_open_order(),  # Exchange A
                self.engineB.get_open_order()   # Exchange B
            ]
            responses = self.send_request(request_list)

            # Check if we got responses from both exchanges
            if not responses[0] or not responses[1]:
                logger.error(f"Failed to get open orders: {responses}")
                return False
            
            # Check if we have any open orders
            if responses[0].parsed or responses[1].parsed:
                # We have open orders! Save them
                self.engineA.openOrders = responses[0].parsed or []
                self.engineB.openOrders = responses[1].parsed or []
                total_orders = len(self.engineA.openOrders) + len(self.engineB.openOrders)
                logger.info(f"Found {total_orders} open orders")
                self.openOrderCheckCount += 1
            else:
                # No open orders! We're free to trade
                self.hasOpenOrder = False
                logger.info("No open orders - ready to check for opportunities!")
    
    def cancel_all_orders(self):
        """
        Cancel all open orders on BOTH exchanges.
        
        Why would we do this?
        - Sometimes orders don't fill quickly
        - We might want to try a different strategy
        - Or prices changed and our orders are no longer good
        """
        logger.info("Cancelling all open orders on both exchanges...")
        
        # List to store cancel requests
        cancel_requests = []
        
        # Cancel orders on Exchange A
        logger.info(f"Cancelling orders on {self.exParams['exchangeA']['exchange']}")
        if hasattr(self.engineA, 'openOrders') and self.engineA.openOrders:
            for order in self.engineA.openOrders:
                logger.debug(f"Cancelling order: {order}")
                cancel_requests.append(self.engineA.cancel_order(order['orderId']))

        # Cancel orders on Exchange B
        logger.info(f"Cancelling orders on {self.exParams['exchangeB']['exchange']}")
        if hasattr(self.engineB, 'openOrders') and self.engineB.openOrders:
            for order in self.engineB.openOrders:
                logger.debug(f"Cancelling order: {order}")
                cancel_requests.append(self.engineB.cancel_order(order['orderId']))

        # Send all cancel requests at once
        if cancel_requests:
            try:
                responses = self.send_request(cancel_requests)
                logger.info(f"✓ Successfully cancelled {len(responses)} orders")
            except Exception as e:
                logger.error(f"Error cancelling orders: {e}")
        else:
            logger.info("No open orders to cancel")
        
        # Clear our lists of open orders
        self.engineA.openOrders = []
        self.engineB.openOrders = []
        self.hasOpenOrder = False

    def check_balance(self):
        """
        Check how much money we have on BOTH exchanges.
        
        Why is this important?
        - We need to know if we have enough currency on each exchange
        - Can't buy on Exchange A if we don't have money there!
        - Can't sell on Exchange B if we don't have currency there!
        
        Returns:
        --------
        True if balance check succeeded, False if it failed
        """
        try:
            # Ask BOTH exchanges: "How much money do I have?"
            request_list = [
                # Exchange A: Check balances for both currencies
                self.engineA.get_balance([
                    self.exParams['exchangeA']['tickerA'],  # First currency (like BTC)
                    self.exParams['exchangeA']['tickerB']   # Second currency (like ETH)
                ]),
                # Exchange B: Check balances for both currencies
                self.engineB.get_balance([
                    self.exParams['exchangeB']['tickerA'],  # First currency (like BTC)
                    self.exParams['exchangeB']['tickerB']   # Second currency (like ETH)
                ])
            ]

            # Send requests and get responses
            responses = self.send_request(request_list)
            
            # Save our balances
            self.engineA.balance = responses[0].parsed
            self.engineB.balance = responses[1].parsed
            
            # Show our balances (for debugging)
            logger.debug("Current balances:")
            logger.debug(f"  {self.exParams['exchangeA']['exchange']}: {self.engineA.balance}")
            logger.debug(f"  {self.exParams['exchangeB']['exchange']}: {self.engineB.balance}")
            
            # In production mode, check if balances are too low
            if not self.mock:
                for response in responses:
                    for ticker in response.parsed:
                        # If balance is too low, warn and return False
                        if response.parsed[ticker] < 0.05:
                            logger.warning(
                                f"{ticker} balance {response.parsed[ticker]} is too low "
                                f"(minimum: 0.05)"
                            )
                            return False
            
            return True
        except Exception as e:
            logger.error(f"Error checking balance: {e}")
            return False
    
    def rebalance(self):
        """
        Rebalance funds between exchanges.
        
        What does this mean?
        - Sometimes we have too much money on Exchange A
        - And not enough on Exchange B
        - We need to move money around
        
        NOTE: This is not implemented yet - it's a placeholder for future work!
        """
        logger.warning("Rebalancing not yet implemented")
        logger.info("You may need to manually transfer funds between exchanges")

    def check_order_book(self):
        """
        Check the order books on BOTH exchanges to find arbitrage opportunities.
        
        What is an order book?
        - It shows the current prices people want to buy/sell at
        - "Bid" = highest price someone wants to BUY
        - "Ask" = lowest price someone wants to SELL
        
        This function:
        1. Gets current prices from Exchange A and Exchange B
        2. Calculates the price difference
        3. If difference is big enough (after fees), we found an opportunity!
        
        Returns:
        --------
        Dictionary with:
        - 'status': 0 = no opportunity, 1 = buy A sell B, 2 = buy B sell A
        - 'ask': Price to buy at
        - 'bid': Price to sell at
        - 'maxAmount': Maximum amount we can trade
        """
        # ====================================================================
        # STEP 1: Get the order book (current prices) from BOTH exchanges
        # ====================================================================
        order_book_requests = [
            # Get prices from Exchange A
            self.engineA.get_ticker_orderBook_innermost(
                self.exParams['exchangeA']['tickerPair']
            ),
            # Get prices from Exchange B
            self.engineB.get_ticker_orderBook_innermost(
                self.exParams['exchangeB']['tickerPair']
            )
        ]

        # Send requests and get responses
        responses = self.send_request(order_book_requests)
        
        # Show prices (for debugging)
        logger.debug(
            f"{self.exParams['exchangeA']['exchange']} - {responses[0].parsed}; "
            f"{self.exParams['exchangeB']['exchange']} - {responses[1].parsed}"
        )

        # ====================================================================
        # STEP 2: Calculate price differences
        # ====================================================================
        # Difference 1: Exchange A's ask price - Exchange B's bid price
        # If negative, Exchange A is cheaper (we can buy there and sell on B)
        diff_A = responses[0].parsed['ask']['price'] - responses[1].parsed['bid']['price']
        
        # Difference 2: Exchange B's ask price - Exchange A's bid price
        # If negative, Exchange B is cheaper (we can buy there and sell on A)
        diff_B = responses[1].parsed['ask']['price'] - responses[0].parsed['bid']['price']
        
        # Handle edge case where both differences are negative
        # (both exchanges are cheaper than each other - shouldn't happen, but just in case)
        if diff_A < 0 and diff_B < 0 and abs(diff_A) < abs(diff_B):
            diff_A = 0
        
        # ====================================================================
        # STEP 3: Check if we can profit by buying on A and selling on B
        # ====================================================================
        if diff_A < 0:
            # Exchange A is cheaper! Buy there, sell on B
            
            # Calculate maximum amount we can trade
            max_amount = self.get_max_amount(
                responses[0].parsed['ask'],  # Buy price on Exchange A
                responses[1].parsed['bid'],  # Sell price on Exchange B
                1  # Route type 1: Buy A, Sell B
            )
            
            # Calculate trading fees (both exchanges charge fees!)
            fee = (
                self.engineA.feeRatio * max_amount * responses[0].parsed['ask']['price'] +  # Fee on Exchange A
                self.engineB.feeRatio * max_amount * responses[1].parsed['bid']['price']     # Fee on Exchange B
            )

            # Calculate profit: price difference * amount - fees
            profit = abs(diff_A * max_amount) - fee
            
            # Check if profit is big enough
            if profit > self.minProfit:
                logger.info(
                    f"🎯 ARBITRAGE OPPORTUNITY FOUND (Route 1)!"
                    f" Buy on {self.exParams['exchangeA']['exchange']} @ {responses[0].parsed['ask']['price']}, "
                    f"Sell on {self.exParams['exchangeB']['exchange']} @ {responses[1].parsed['bid']['price']}"
                )
                logger.info(
                    f"  Price difference: {diff_A}, "
                    f"Profit: {profit:.8f}, Fee: {fee:.8f}, Amount: {max_amount:.8f}"
                )
                return {
                    'status': 1,  # Route 1: Buy A, Sell B
                    'ask': responses[0].parsed['ask']['price'],
                    'bid': responses[1].parsed['bid']['price'],
                    'maxAmount': max_amount
                }
            else:
                # Profit too small, skip it
                return {'status': 0}

        # ====================================================================
        # STEP 4: Check if we can profit by buying on B and selling on A
        # ====================================================================
        elif diff_B < 0:
            # Exchange B is cheaper! Buy there, sell on A
            
            # Calculate maximum amount we can trade
            max_amount = self.get_max_amount(
                responses[1].parsed['ask'],  # Buy price on Exchange B
                responses[0].parsed['bid'],  # Sell price on Exchange A
                2  # Route type 2: Buy B, Sell A
            )
            
            # Calculate trading fees (both exchanges charge fees!)
            fee = (
                self.engineB.feeRatio * max_amount * responses[1].parsed['ask']['price'] +  # Fee on Exchange B
                self.engineA.feeRatio * max_amount * responses[0].parsed['bid']['price']     # Fee on Exchange A
            )

            # Calculate profit: price difference * amount - fees
            profit = abs(diff_B * max_amount) - fee
            
            # Check if profit is big enough
            if profit > self.minProfit:
                logger.info(
                    f"🎯 ARBITRAGE OPPORTUNITY FOUND (Route 2)!"
                    f" Buy on {self.exParams['exchangeB']['exchange']} @ {responses[1].parsed['ask']['price']}, "
                    f"Sell on {self.exParams['exchangeA']['exchange']} @ {responses[0].parsed['bid']['price']}"
                )
                logger.info(
                    f"  Price difference: {diff_B}, "
                    f"Profit: {profit:.8f}, Fee: {fee:.8f}, Amount: {max_amount:.8f}"
                )
                return {
                    'status': 2,  # Route 2: Buy B, Sell A
                    'ask': responses[1].parsed['ask']['price'],
                    'bid': responses[0].parsed['bid']['price'],
                    'maxAmount': max_amount
                }
            else:
                # Profit too small, skip it
                return {'status': 0}

        # No opportunity found
        return {'status': 0}

    def get_max_amount(self, ask_order, bid_order, route_type):
        """
        Calculate the maximum amount we can trade.
        
        Why do we need this?
        - We can't trade more than we have (balance limit)
        - We can't trade more than what's available (order book limit)
        - We need to find the smallest limit to stay safe
        
        Parameters:
        -----------
        ask_order: Order book data for buying (has 'price' and 'amount')
        bid_order: Order book data for selling (has 'price' and 'amount')
        route_type: Which route (1 = buy A sell B, 2 = buy B sell A)
        
        Returns:
        --------
        Maximum amount we can trade (float)
        """
        amount = 0
        
        # ====================================================================
        # ROUTE 1: Buy on Exchange A, Sell on Exchange B
        # ====================================================================
        if route_type == 1:
            # We need currency A on Exchange A to buy
            ticker_a = self.exParams['exchangeA']['tickerA']
            # We need currency B on Exchange B to sell
            ticker_b = self.exParams['exchangeB']['tickerB']
            
            # Calculate how much we can buy on Exchange A
            # (accounting for fees and price)
            max_own_amount_a = (
                self.engineA.balance.get(ticker_a, 0) /
                ((1 + self.engineA.feeRatio) * ask_order['price'])
            )
            
            # How much we can sell on Exchange B (we own this much)
            max_own_amount_b = self.engineB.balance.get(ticker_b, 0)
            
            # We can only trade the smallest of:
            # - What we can buy on A
            # - What we can sell on B
            # - What's available in the order book
            amount = min(
                max_own_amount_a,      # Limited by our balance on A
                max_own_amount_b,      # Limited by our balance on B
                ask_order['amount'],    # Limited by order book on A
                bid_order['amount']     # Limited by order book on B
            )
            
        # ====================================================================
        # ROUTE 2: Buy on Exchange B, Sell on Exchange A
        # ====================================================================
        elif route_type == 2:
            # We need currency B on Exchange A to sell
            ticker_a = self.exParams['exchangeA']['tickerB']
            # We need currency A on Exchange B to buy
            ticker_b = self.exParams['exchangeB']['tickerA']
            
            # How much we can sell on Exchange A (we own this much)
            max_own_amount_a = self.engineA.balance.get(ticker_a, 0)
            
            # Calculate how much we can buy on Exchange B
            # (accounting for fees and price)
            max_own_amount_b = (
                self.engineB.balance.get(ticker_b, 0) /
                ((1 + self.engineB.feeRatio) * ask_order['price'])
            )
            
            # We can only trade the smallest of:
            # - What we can sell on A
            # - What we can buy on B
            # - What's available in the order book
            amount = min(
                max_own_amount_a,      # Limited by our balance on A
                max_own_amount_b,      # Limited by our balance on B
                ask_order['amount'],    # Limited by order book on B
                bid_order['amount']     # Limited by order book on A
            )

        return amount

    def place_order(self, status, ask, bid, amount):
        """
        Actually place the orders on BOTH exchanges!
        
        Parameters:
        -----------
        status: Which route (1 = buy A sell B, 2 = buy B sell A)
        ask: Price to buy at
        bid: Price to sell at
        amount: How much to trade
        """
        logger.info(f"📝 Preparing to place orders for {amount:.8f} amount...")
        
        # ====================================================================
        # ROUTE 1: Buy on Exchange A, Sell on Exchange B
        # ====================================================================
        if status == 1:
            logger.info(
                f"Buy at {ask} @ {self.exParams['exchangeA']['exchange']} & "
                f"Sell at {bid} @ {self.exParams['exchangeB']['exchange']} "
                f"for {amount:.8f}"
            )
            
            # Create order requests
            order_requests = [
                # Buy on Exchange A
                self.engineA.place_order(
                    self.exParams['exchangeA']['tickerPair'],
                    'bid',  # Buy
                    amount,
                    ask
                ),
                # Sell on Exchange B
                self.engineB.place_order(
                    self.exParams['exchangeB']['tickerPair'],
                    'ask',  # Sell
                    amount,
                    bid
                ),
            ]
            
        # ====================================================================
        # ROUTE 2: Buy on Exchange B, Sell on Exchange A
        # ====================================================================
        elif status == 2:
            logger.info(
                f"Buy at {ask} @ {self.exParams['exchangeB']['exchange']} & "
                f"Sell at {bid} @ {self.exParams['exchangeA']['exchange']} "
                f"for {amount:.8f}"
            )
            
            # Create order requests
            order_requests = [
                # Buy on Exchange B
                self.engineB.place_order(
                    self.exParams['exchangeB']['tickerPair'],
                    'bid',  # Buy
                    amount,
                    ask
                ),
                # Sell on Exchange A
                self.engineA.place_order(
                    self.exParams['exchangeA']['tickerPair'],
                    'ask',  # Sell
                    amount,
                    bid
                ),
            ]

        # If we're NOT in mock mode, actually place the orders!
        if not self.mock:
            try:
                responses = self.send_request(order_requests)
                logger.info("✅ Orders placed successfully on both exchanges!")
            except Exception as e:
                logger.error(f"❌ Error placing orders: {e}")
                raise
        else:
            # Mock mode - just pretend we placed them
            logger.info("🔒 Mock mode: Orders NOT actually placed (safe mode)")
            
        # Mark that we now have open orders
        self.hasOpenOrder = True
        self.openOrderCheckCount = 0

    def send_request(self, requests_list):
        """
        Send multiple API requests to the exchanges at the same time.
        
        Why send multiple at once?
        - Faster! We can ask for multiple things simultaneously
        - Exchanges allow this
        
        Parameters:
        -----------
        requests_list: List of requests to send
        
        Returns:
        --------
        List of responses from the exchanges
        """
        # Send all requests at once (async)
        responses = grequests.map(requests_list)
        
        # Check if any requests failed
        for i, response in enumerate(responses):
            if not response:
                logger.error(f"Request {i} failed: {responses}")
                raise Exception(f"Request {i} failed")
        
        return responses

    def run(self):
        """
        Start the engine! This is called from main.py
        """
        self.start_engine()


# ============================================================================
# TESTING CODE - Only runs if you run this file directly
# ============================================================================
if __name__ == '__main__':
    # Example configuration for testing
    exParams = {
        'exchangeA': {
            'exchange': 'bittrex',
            'keyFile': '../keys/bittrex.key',
            'tickerPair': 'BTC-ETH',
            'tickerA': 'BTC',
            'tickerB': 'ETH'        
        },
        'exchangeB': {
            'exchange': 'bitstamp',
            'keyFile': '../keys/bitstamp.key',
            'tickerPair': 'ethbtc',
            'tickerA': 'btc',
            'tickerB': 'eth'         
        }
    }
    # Create engine in mock mode (safe!)
    engine = CryptoEngineExArbitrage(exParams, True)
    engine.run()
