"""
Exchange Engine Loader
Dynamically loads exchange engine implementations
"""

import sys
import os
import logging

logger = logging.getLogger(__name__)

# Add exchanges directory to path
sys.path.append(os.path.dirname(__file__))


class EngineLoader:
    """Factory class for loading exchange engines."""
    
    @staticmethod
    def getEngine(exchange_name, key_file):
        """
        Get an exchange engine instance.
        
        Args:
            exchange_name: Name of the exchange (e.g., 'bittrex', 'bitfinex')
            key_file: Path to the API key file
            
        Returns:
            ExchangeEngine instance
            
        Raises:
            ImportError: If exchange module cannot be imported
            FileNotFoundError: If key file does not exist
        """
        try:
            # Import the exchange module
            mod = __import__(
                f'engines.exchanges.{exchange_name}',
                fromlist=['ExchangeEngine']
            )
            engine = mod.ExchangeEngine()
            engine.load_key(key_file)
            logger.debug(f"Loaded {exchange_name} engine with key file {key_file}")
            return engine
        except ImportError as e:
            logger.error(f"Failed to import {exchange_name} module: {e}")
            raise
        except Exception as e:
            logger.error(f"Failed to initialize {exchange_name} engine: {e}")
            raise

    