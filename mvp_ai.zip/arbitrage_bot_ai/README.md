# Cryptocurrency Arbitrage Trading Bot

[![Python 3](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)

## 🎯 What Is This?

This is a **trading bot** - a computer program that automatically finds and makes profitable trades for you!

**Think of it like this:**
- You know how sometimes stores sell the same thing for different prices?
- This bot finds those price differences and buys low, sells high automatically
- It works 24/7, never sleeps, and acts super fast!

## 🤔 What Is Arbitrage? (Simple Explanation)

**Arbitrage** = Buying something cheap and selling it expensive at the same time to make profit.

### Real-World Example:
Imagine you see:
- **Store A**: Selling apples for $1.00
- **Store B**: Buying apples for $1.10

If you buy from Store A and sell to Store B, you make $0.10 profit per apple!

This bot does the same thing, but with cryptocurrency on exchanges.

## 🎮 Two Types of Arbitrage This Bot Does

### 1. Triangular Arbitrage (On ONE Exchange)
**What it does:** Finds profit by trading through 3 currencies in a circle.

**Example:**
- Start with 1 BTC
- Trade BTC → ETH (buy ETH with BTC)
- Trade ETH → LTC (buy LTC with ETH)
- Trade LTC → BTC (sell LTC for BTC)
- **If you end up with MORE than 1 BTC = PROFIT!** 🎉

**Why it works:** Sometimes prices between these 3 pairs don't match perfectly, creating opportunities.

### 2. Exchange Arbitrage (Between TWO Exchanges)
**What it does:** Finds price differences between two different exchanges.

**Example:**
- **Exchange A**: Selling BTC for $50,000
- **Exchange B**: Buying BTC for $50,100
- Buy on Exchange A, sell on Exchange B = **$100 profit!** 💰

**Why it works:** Different exchanges sometimes have slightly different prices for the same currency.

## ✨ What This Bot Can Do

- ✅ **Automatically finds** arbitrage opportunities
- ✅ **Places trades** for you (if you want)
- ✅ **Works 24/7** - never sleeps!
- ✅ **Safe testing mode** - test without risking money
- ✅ **Works with multiple exchanges** - Bittrex, Bitfinex, Bitstamp, Kraken
- ✅ **Shows you everything** - logs all activities

## 📋 What You Need Before Starting

### 1. Python (The Programming Language)
- **Download:** [Python 3.7 or higher](https://www.python.org/downloads/)
- **How to check if you have it:** Open terminal/command prompt and type: `python --version`
- **If you see a version number:** You're good! ✅
- **If you see an error:** Download Python from the link above

### 2. Exchange Accounts
You need accounts on cryptocurrency exchanges (like Bittrex, Bitfinex, etc.)

**What you need from each exchange:**
- Account (sign up like any website)
- API Keys (like a password that lets the bot trade for you)
  - Public Key (like your username)
  - Private Key (like your password - KEEP SECRET!)

### 3. Some Cryptocurrency
You need actual coins to trade with (BTC, ETH, etc.)

**Important:** Start small! Don't risk more than you can afford to lose.

## 🚀 Step-by-Step Setup Guide

### Step 1: Download the Code

**Option A: If you have Git installed**
```bash
git clone <repository-url>
cd crypto-arbitrage-master
```

**Option B: If you don't have Git**
1. Click the "Download" button on GitHub
2. Extract the ZIP file
3. Open a terminal/command prompt in that folder

### Step 2: Set Up Python Environment (Recommended)

**What is this?** It's like creating a clean workspace so your bot doesn't interfere with other Python programs.

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Mac/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**How do you know it worked?** You should see `(venv)` at the start of your command line.

### Step 3: Install Required Tools

The bot needs some Python "tools" (called packages) to work.

```bash
pip install -r requirements.txt
```

**What this does:** Downloads and installs all the tools the bot needs.

**How long does it take?** Usually 1-2 minutes.

### Step 4: Get Your API Keys

**What are API keys?** They're like special passwords that let the bot talk to exchanges.

**How to get them:**
1. Log into your exchange account (like Bittrex, Bitfinex, etc.)
2. Go to "API Settings" or "API Keys" section
3. Create a new API key
4. **IMPORTANT:** Give it "Read" and "Trade" permissions (NOT "Withdraw" - that's dangerous!)
5. Copy your Public Key and Private Key

**⚠️ SECURITY WARNING:**
- Never share your API keys with anyone!
- Never upload them to the internet!
- The `.gitignore` file protects you, but be careful!

### Step 5: Set Up Your API Keys

1. **Find the sample files:**
   - Look in the `keys/` folder
   - You'll see files like `bittrex.key_sample`, `bitfinex.key_sample`, etc.

2. **Copy the sample file:**
   - **Windows:** Copy `bittrex.key_sample` and rename it to `bittrex.key`
   - **Mac/Linux:** Run: `cp keys/bittrex.key_sample keys/bittrex.key`

3. **Edit the file:**
   - Open `keys/bittrex.key` in a text editor (Notepad, TextEdit, etc.)
   - Replace the example values with YOUR real keys:
   ```json
   {
     "exchange": "bittrex",
     "api_name": "bittrexapi",
     "public": "YOUR_PUBLIC_KEY_HERE",
     "private": "YOUR_PRIVATE_KEY_HERE"
   }
   ```
   - Save the file

4. **Repeat for other exchanges** you want to use

### Step 6: Configure What to Trade

1. **Open `arbitrage_config.json`** in a text editor

2. **For Triangular Arbitrage:**
   ```json
   {
     "triangular": {
       "exchange": "bittrex",
       "keyFile": "keys/bittrex.key",
       "tickerPairA": "BTC-ETH",
       "tickerPairB": "ETH-LTC",
       "tickerPairC": "BTC-LTC",
       "tickerA": "BTC",
       "tickerB": "ETH",
       "tickerC": "LTC"
     }
   }
   ```
   
   **What this means:**
   - `exchange`: Which exchange to use
   - `keyFile`: Where your API keys are stored
   - `tickerPairA/B/C`: The 3 trading pairs to use (like BTC-ETH)
   - `tickerA/B/C`: The 3 currencies (like BTC, ETH, LTC)

3. **For Exchange Arbitrage:**
   ```json
   {
     "exchange": {
       "exchangeA": {
         "exchange": "bittrex",
         "keyFile": "keys/bittrex.key",
         "tickerPair": "BTC-ETH",
         "tickerA": "BTC",
         "tickerB": "ETH"
       },
       "exchangeB": {
         "exchange": "bitstamp",
         "keyFile": "keys/bitstamp.key",
         "tickerPair": "ethbtc",
         "tickerA": "btc",
         "tickerB": "eth"
       }
     }
   }
   ```
   
   **What this means:**
   - `exchangeA`: First exchange settings
   - `exchangeB`: Second exchange settings
   - The bot will compare prices between these two exchanges

4. **Save the file**

## 🎮 How to Use the Bot

### ⚠️ IMPORTANT: Start in Safe Mode First!

**Always test in MOCK MODE first!** This lets you see what the bot would do WITHOUT actually placing trades.

### Running Triangular Arbitrage

**Safe Mode (Recommended First):**
```bash
python main.py -m triangular
```

**What happens:**
- Bot starts looking for opportunities
- Shows you what it finds
- **Does NOT place real trades** ✅
- You can watch and learn!

**Production Mode (Real Trades):**
```bash
python main.py -m triangular -p
```

**What happens:**
- Bot starts looking for opportunities
- **Actually places trades** ⚠️
- Uses real money!

### Running Exchange Arbitrage

**Safe Mode:**
```bash
python main.py -m exchange
```

**Production Mode:**
```bash
python main.py -m exchange -p
```

### Understanding the Command

Let's break down: `python main.py -m triangular -p`

- `python` = Run Python
- `main.py` = The main program file
- `-m triangular` = Use triangular arbitrage mode
- `-p` = Production mode (real trades)

**Without `-p`** = Mock mode (safe, no real trades)

## 📊 Understanding the Output

When the bot runs, you'll see messages like:

```
2026-02-05 10:30:15 - INFO - Starting Triangular Arbitrage Engine...
2026-02-05 10:30:15 - WARNING - MOCK MODE ENABLED - NO ORDERS WILL BE PLACED
2026-02-05 10:30:20 - INFO - 🎯 BID ROUTE OPPORTUNITY FOUND! Result=1.001234 Profit=$5.23 Fee=$2.10 Net Profit=$3.13
```

**What this means:**
- `INFO` = Normal message
- `WARNING` = Important notice (like mock mode)
- `ERROR` = Something went wrong
- `🎯` = Found an opportunity!
- `Profit` = How much you'd make
- `Fee` = Trading fees
- `Net Profit` = Profit after fees

## 📁 Understanding the Files

```
crypto-arbitrage-master/
│
├── main.py                          ← START HERE! Main program
├── requirements.txt                 ← List of tools needed
├── arbitrage_config.json            ← Your settings (what to trade)
├── arbitrage.log                    ← Log file (created automatically)
│
├── engines/                         ← The "brain" of the bot
│   ├── triangular_arbitrage.py     ← Triangular arbitrage logic
│   ├── exchange_arbitrage.py        ← Exchange arbitrage logic
│   └── exchanges/                   ← Exchange connections
│       ├── bittrex.py              ← How to talk to Bittrex
│       ├── bitfinex.py             ← How to talk to Bitfinex
│       └── ...                      ← Other exchanges
│
└── keys/                            ← Your API keys (KEEP SECRET!)
    ├── bittrex.key_sample           ← Example file
    └── bittrex.key                  ← Your real keys (create this)
```

## ⚙️ Customizing the Bot

### Change Minimum Profit

**What is this?** The bot only trades if profit is above a certain amount.

**Triangular Arbitrage:**
1. Open `engines/triangular_arbitrage.py`
2. Find: `self.minProfitUSDT = 0.3`
3. Change to: `self.minProfitUSDT = 1.0` (for $1.00 minimum)
4. Save the file

**Exchange Arbitrage:**
1. Open `engines/exchange_arbitrage.py`
2. Find: `self.minProfit = 0.00005`
3. Change to a higher number for bigger minimum profit
4. Save the file

### Change How Often It Checks

1. Open the exchange file (like `engines/exchanges/bittrex.py`)
2. Find: `self.sleepTime = 5`
3. Change to: `self.sleepTime = 10` (check every 10 seconds instead of 5)
4. Save the file

**Note:** Checking too often might get you banned by the exchange!

## 🐛 Troubleshooting (Common Problems)

### Problem: "Python not found"
**Solution:** 
- Make sure Python is installed
- Try `python3` instead of `python`
- Add Python to your PATH

### Problem: "Module not found" or "Import error"
**Solution:**
```bash
pip install -r requirements.txt
```

### Problem: "API key error" or "Authentication failed"
**Solution:**
- Check that your API keys are correct
- Make sure you copied them completely (no extra spaces)
- Verify the keys have "Trade" permission enabled

### Problem: "Balance too low"
**Solution:**
- Make sure you have enough cryptocurrency on the exchange
- Check that you're using the right currencies in the config
- Try with smaller amounts first

### Problem: "No opportunities found"
**Solution:**
- This is normal! Arbitrage opportunities are rare
- Try different currency pairs
- Check that exchanges are working properly
- Lower the minimum profit threshold (but be careful!)

### Problem: "Connection error"
**Solution:**
- Check your internet connection
- Check if the exchange website is working
- Try again later (exchanges sometimes have downtime)

## ⚠️ Important Safety Tips

### 1. Always Test First! 🧪
- **NEVER** use production mode (`-p`) until you've tested in mock mode
- Watch the bot for at least 30 minutes in mock mode
- Make sure you understand what it's doing

### 2. Start Small 💰
- Don't trade with all your money at once
- Start with small amounts you can afford to lose
- Learn how it works before scaling up

### 3. Understand Trading Fees 💸
- Every trade costs money (usually 0.25-0.26%)
- The bot accounts for this, but be aware
- Small profits might not be worth it after fees

### 4. Monitor Your Bot 👀
- Don't just start it and walk away
- Check the logs regularly (`arbitrage.log`)
- Make sure it's working correctly

### 5. Keep Your Keys Safe 🔒
- Never share your API keys
- Never upload them anywhere
- Use "Trade" permission only (NOT "Withdraw")

### 6. Market Volatility 📈
- Prices change FAST
- Opportunities disappear quickly
- The bot is fast, but not instant

## 🎓 Quick Reference

### Common Commands

```bash
# Test triangular arbitrage (safe)
python main.py -m triangular

# Test exchange arbitrage (safe)
python main.py -m exchange

# Run triangular arbitrage (REAL TRADES!)
python main.py -m triangular -p

# Run exchange arbitrage (REAL TRADES!)
python main.py -m exchange -p

# Use a different config file
python main.py -m triangular -c my_config.json
```

### File Locations

- **Config file:** `arbitrage_config.json`
- **API keys:** `keys/bittrex.key`, `keys/bitfinex.key`, etc.
- **Logs:** `arbitrage.log`
- **Main program:** `main.py`

### Key Settings

- **Minimum profit:** `engines/triangular_arbitrage.py` (line ~26)
- **Check frequency:** `engines/exchanges/bittrex.py` (line ~12)
- **Trading pairs:** `arbitrage_config.json`

## 🎉 You're Ready!

You now know:
- ✅ What arbitrage is
- ✅ How to set up the bot
- ✅ How to run it safely
- ✅ How to customize it
- ✅ How to troubleshoot problems

**Remember:**
1. **Always test in mock mode first!**
2. **Start small!**
3. **Keep learning!**
4. **Stay safe!**

---

## 📝 License & Disclaimer

This project is for **educational purposes only**.

**⚠️ IMPORTANT WARNINGS:**
- Cryptocurrency trading involves **significant risk**
- You can **lose money**
- Only trade with money you can **afford to lose**
- The authors are **not responsible** for any losses
- **Test thoroughly** before using real money
- **Never** risk more than you can afford to lose

**Use at your own risk!**

---

**Happy Trading! 🚀**

*Remember: With great power comes great responsibility. Trade wisely!*
