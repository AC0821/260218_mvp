"""
Cryptocurrency Arbitrage Engines Package
"""

__version__ = '2.0.0'
