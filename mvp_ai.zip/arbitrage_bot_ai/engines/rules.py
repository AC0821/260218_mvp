"""
Rule Checker for Trading Rules
Implements various trading rules for market analysis
"""

import logging

logger = logging.getLogger(__name__)


class RuleChecker:
    """Checker for various trading rules."""
    
    def __init__(self):
        """Initialize the rule checker."""
        pass

    def check(self, rule, data):
        """
        Check a trading rule against data.
        
        Args:
            rule: Name of the rule to check
            data: Data dictionary with format {'data': [...], 'exchange': str, 'ticker': str}
            
        Returns:
            bool: True if rule condition is met, False otherwise
        """
        if not hasattr(self, rule):
            logger.error(f"Rule '{rule}' not found")
            return False
        return getattr(self, rule)(data)

    def oldest_newest_single_larger_than_5per(self, ticker_data):
        """
        Check if oldest vs newest single price change is larger than 5%.
        
        Args:
            ticker_data: Dictionary with 'data' key containing price data
            
        Returns:
            bool: True if condition is met
        """
        data = ticker_data['data']
        logger.debug(f"Checking oldest_newest_single_larger_than_5per: {data}")
        return True
    
    def oldest_latest_avg_of_5_larger_than_5per(self, ticker_data):
        """
        Check if the difference between oldest and latest average of 5 prices
        is larger than 5%.
        
        Args:
            ticker_data: Dictionary with 'data', 'exchange', and 'ticker' keys
            
        Returns:
            bool: True if percentage change > 5%
        """
        data = ticker_data['data']
        parsed_data = [float(x['price']) for x in data]

        if len(data) < 10:
            logger.warning(
                f"Failed for rule oldest_latest_avg_of_5_larger_than_5per: "
                f"There are fewer than 10 data points"
            )
            return False

        latest_avg = sum(parsed_data[:5]) / 5.0
        oldest_avg = sum(parsed_data[-5:]) / 5.0
        
        percentage_change = 100 * (latest_avg - oldest_avg) / oldest_avg
        
        msg = (
            f"{ticker_data['exchange']} - {ticker_data['ticker']} - "
            f"oldest_latest_avg_of_5_larger_than_5per: {percentage_change:.2f}%"
        )
        
        if abs(percentage_change) > 5:
            logger.warning(f"!!!ALERT!!! {msg} !!!ALERT!!!")
            return True
        
        logger.info(msg)
        return False


if __name__ == '__main__':
    # Example usage
    data = [
        {'price': 4615}, {'price': 4615}, {'price': 4380}, {'price': 3935.1},
        {'price': 4149.9}, {'price': 3918}, {'price': 3850}, {'price': 3720},
        {'price': 3700}, {'price': 3579.7}, {'price': 3499.8}, {'price': 3499.1},
        {'price': 3699.8}, {'price': 3577}, {'price': 3577.1}, {'price': 3644.6},
        {'price': 3546.3}, {'price': 3480.2}, {'price': 3354.8}, {'price': 3310.6},
        {'price': 3132.1}, {'price': 3152.1}, {'price': 2995.2}, {'price': 3167},
        {'price': 3387}, {'price': 3374.3}, {'price': 3421.1}, {'price': 3091.8},
        {'price': 2993}, {'price': 3092.7}, {'price': 2947.9}, {'price': 3254.4},
        {'price': 3540}, {'price': 3514.3}, {'price': 3474.1}, {'price': 3601.6},
        {'price': 3750}, {'price': 3947.4}, {'price': 3892.3}, {'price': 3653.6},
        {'price': 3588.9}, {'price': 3774.7}, {'price': 3863.6}, {'price': 4051.2},
        {'price': 3946.5}, {'price': 3827.9}, {'price': 3811.7}, {'price': 3619},
        {'price': 3671.9}, {'price': 3661}, {'price': 3751.7}, {'price': 3592.3},
        {'price': 3601.2}, {'price': 3396.9}, {'price': 3458.4}, {'price': 3508.4},
        {'price': 3424.8}, {'price': 3670.5}, {'price': 3772.1}, {'price': 3674.8},
        {'price': 3454.21}, {'price': 3602}, {'price': 3357.9}, {'price': 3283.7},
        {'price': 3042.3}, {'price': 2927.9}, {'price': 2814.1}, {'price': 2900.7},
        {'price': 2834.7}, {'price': 2729.5}, {'price': 2705.7}, {'price': 2438.5},
        {'price': 2341}, {'price': 2279.4}, {'price': 2309}, {'price': 2321.1},
        {'price': 2201.7}, {'price': 2287.2}, {'price': 2368.2}, {'price': 2172},
        {'price': 2091}, {'price': 2196.7}, {'price': 2363.1}, {'price': 2361.3},
        {'price': 2365.5}, {'price': 2358.3}, {'price': 2241.3}, {'price': 2050},
        {'price': 2000}, {'price': 1888.52}, {'price': 1686.05}, {'price': 1851.1199},
        {'price': 1999}, {'price': 2087.9999}, {'price': 2059.6}, {'price': 2137.94},
        {'price': 2140}, {'price': 2247.81705}, {'price': 2235.185}, {'price': 2260.62005}
    ]

    checker = RuleChecker()
    ticker_data = {
        'data': data,
        'exchange': 'gatecoin',
        'ticker': 'BTCHKD'
    }
    result = checker.check('oldest_latest_avg_of_5_larger_than_5per', ticker_data)
    print(f"Rule check result: {result}")
