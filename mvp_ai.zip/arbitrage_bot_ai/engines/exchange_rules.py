"""
Exchange Rules Engine
Monitors exchanges and checks trading rules
"""

import time
import logging
import threading
from engines.rules import RuleChecker

logger = logging.getLogger(__name__)


class CryptoEngineRules:
    """
    Engine for monitoring exchanges and checking trading rules.
    
    exchange: Exchange module name (filename)
    """
    
    def __init__(self, exchange, ticker, rule, key_file):
        """
        Initialize the rules engine.
        
        Args:
            exchange: Exchange module name
            ticker: Ticker symbol to monitor
            rule: Rule name to check
            key_file: Path to API key file
        """
        self.exchange = exchange
        self.ticker = ticker
        self.rule = rule
        self.key_file = key_file
        self.checker = RuleChecker()
  
    def start_engine(self):
        """Start the rules checking engine."""
        logger.info(f"Starting rules engine for {self.exchange} - {self.ticker}")
        
        try:
            mod = __import__(self.exchange)
            cls = mod.ExchangeEngine()
            cls.load_key(self.key_file)

            while True:
                # For history of about 1 hour ago to now
                try:
                    data = cls.get_ticker_history(self.ticker)
                    parsed_data = cls.parseTickerData(self.ticker, data)
                    self.checker.check(self.rule, parsed_data)
                except Exception as e:
                    logger.error(f"Error checking rule: {e}")
                
                time.sleep(cls.sleepTime)
        except Exception as e:
            logger.error(f"Fatal error in rules engine: {e}", exc_info=True)
    
    def run(self):
        """Run the rules engine in a separate thread."""
        thread = threading.Thread(target=self.start_engine)
        # thread.daemon = True  # Thread is terminated when main script terminates
        thread.start()
        logger.info("Rules engine thread started")


if __name__ == '__main__':
    # Configure logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    exchange = 'gatecoin'
    ticker = 'BTCHKD'
    rule = 'oldest_latest_avg_of_5_larger_than_5per'
    key_file = '../keys/gatecoin.key'
    engine = CryptoEngineRules(exchange, ticker, rule, key_file)
    engine.run()
    
    exchange = 'kraken'
    ticker = 'XRPUSD'
    rule = 'oldest_latest_avg_of_5_larger_than_5per'
    key_file = '../keys/kraken.key'
    engine = CryptoEngineRules(exchange, ticker, rule, key_file)
    engine.run()
